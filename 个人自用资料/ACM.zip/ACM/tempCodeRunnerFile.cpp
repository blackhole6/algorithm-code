onst char *friendGraphTXT = 
"shreya bob"
"bob yang"
"bob shreya"
"yang shreya"
"bob cecilia"
"cecilia michael"
"cecilia bob";