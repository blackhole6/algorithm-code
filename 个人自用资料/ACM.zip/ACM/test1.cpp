#include<bits/stdc++.h>

using namespace std;
const int maxn=1e5+5;
int main(){
    能看到吗？
    ok
    这次延迟呢
    ok 那先这样
    那就下次提前连一下吧
    你再提醒我
    嗯嗯 
    这次是秋招吗
    这次的笔试是秋招吗
    还看的到吗？
    嗯嗯 到时候实在不行我再微信发你份
    这次是秋招吗
    这个就先退了
    return 0;
    111
    12:53
    能看到
    基本每延迟
    还行
    可以
    笔试前再连
    ok
    能
    稍微有些延迟
    但还好
    秋招
    嗯，退了吧
    
    
}