//首先是建树
//2是查询从l到r之间的和
//接着是修改某一个点
// 1 改 第i 个为val

#include<bits/stdc++.h>
using namespace std;
struct node
{
    int val;
    int left, right;
}tree[100];
void upup(int no)
{
    tree[no].val = tree[no << 1].val + tree[no << 1 | 1].val;
 
}
void build(int no,int l,int r)
{
    tree[no].left = l, tree[no].right = r;
    if (tree[no].left == tree[no].right)
    {
        cin >> tree[no].val;
        return;
    }
    int mid = (l + r) >> 1;
    build(no << 1, l, mid);
    build((no << 1)|1, mid + 1, r);
    upup(no);
}
int find(int l, int r,int no)
{
    int mid = (tree[no].left +tree[no].right) >> 1;
    if (l == tree[no].left && r == tree[no].right)
    {
        return tree[no].val;
    }
   
         if ( r <= mid)
            return find(l, r, no << 1);
         if (l > mid )
            return find(l, r, no << 1 | 1);
        else  
            return find(l, mid, no << 1) + find(mid+1, r, no << 1 | 1);
   
   
 
}
void gai(int no,int a)
{
   
    tree[no].val = a;
    while((no>>1)>=1)
    upup(no>>1);
   
}
 
signed main()
{
    int  l, r;
    int a,i;
    int n;
    cin>>n;
    //cin >> l >> r;
    build(1, 1, n);
    int select;
   
    for (int i = 1; i < 100; i++)
    {
        cin >> select;
        if (select == -1)
            break;
        if (select == 1)
        {
            cin >> i >> a;
 
            gai(i, a);
 
        }
        if (select == 2)
        {
            int l,r;
            cin>>l>>r;
            find(l, r, 1);
        }
       
    }
   
    return 0;
}