 if(a.charAt(0)!='y'||a.charAt(0)!='n'){
                System.out.println("输入有误。请重新输入");
            }